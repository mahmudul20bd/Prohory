package com.cyberaware.backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // সব API এর জন্য
                .allowedOrigins(
                        "http://localhost:5173", // Vite Default
                        "http://localhost:5174", // আপনার বর্তমান পোর্ট
                        "http://localhost:3000"  // React Default (Optional)
                )
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}